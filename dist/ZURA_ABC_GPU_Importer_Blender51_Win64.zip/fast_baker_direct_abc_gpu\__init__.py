bl_info = {
    "name": "Fast Baker Direct ABC GPU",
    "author": "OpenAI",
    "version": (0, 2, 1),
    "blender": (5, 1, 0),
    "location": "View3D > Sidebar > Fast Baker Direct",
    "description": "Bake Alembic poly mesh samples into shape keys with a direct Alembic backend.",
    "category": "Object",
}

import math
import os
import time

import bpy
import numpy as np

from bpy.props import BoolProperty, FloatProperty, IntProperty, PointerProperty, StringProperty

BACKEND_IMPORT_ERROR = None
ACTIVE_BAKE_OPERATOR = None

try:
    from . import direct_abc_backend as baker_backend
except Exception as exc:
    baker_backend = None
    BACKEND_IMPORT_ERROR = str(exc)


def _tag_redraw_all():
    window_manager = bpy.context.window_manager
    for window in window_manager.windows:
        screen = window.screen
        if screen is None:
            continue
        for area in screen.areas:
            area.tag_redraw()


def _set_status(settings, message, redraw=True):
    settings.status_text = message
    if redraw:
        _tag_redraw_all()


def _set_all_shape_key_interpolation_linear(obj):
    shape_keys = obj.data.shape_keys
    anim_data = shape_keys.animation_data if shape_keys else None
    action = anim_data.action if anim_data else None
    if not action or not action.slots:
        return

    slot = action.slots[0]

    for layer in action.layers:
        for strip in layer.strips:
            try:
                channel_bag = strip.channelbag(slot)
            except Exception:
                continue

            if not channel_bag:
                continue

            for fcurve in channel_bag.fcurves:
                data_path = fcurve.data_path
                if not data_path.startswith('key_blocks["') or not data_path.endswith('"].value'):
                    continue

                for keyframe in fcurve.keyframe_points:
                    keyframe.interpolation = "LINEAR"


def _abs_archive_path(settings):
    return bpy.path.abspath(settings.archive_path).strip()


def _mesh_label(mesh_path):
    cleaned = mesh_path.strip("/")
    return cleaned.replace("/", "_") if cleaned else "mesh"


def _suggest_frame_range(scene, sample_count):
    start_frame = int(scene.frame_start)
    end_frame = start_frame + max(0, int(sample_count) - 1)
    return start_frame, end_frame


def _auto_samples_per_tick(vertex_count):
    if vertex_count >= 1_000_000:
        return 1
    if vertex_count >= 250_000:
        return 2
    if vertex_count >= 100_000:
        return 4
    return 8


def _auto_viewport_refresh_step(vertex_count):
    if vertex_count >= 1_000_000:
        return 1
    if vertex_count >= 250_000:
        return 2
    return 8


def _create_mesh_object(scene, archive_path, mesh_path, positions, indices, counts):
    archive_stem = os.path.splitext(os.path.basename(archive_path))[0] or "Alembic"
    mesh_label = _mesh_label(mesh_path)
    object_name = f"{archive_stem}_{mesh_label}_Direct"
    mesh_name = f"{object_name}_Mesh"

    mesh = bpy.data.meshes.new(mesh_name)
    vertex_count = len(positions) // 3

    mesh.vertices.add(vertex_count)
    mesh.vertices.foreach_set("co", positions)

    mesh.loops.add(len(indices))
    mesh.loops.foreach_set("vertex_index", indices)

    mesh.polygons.add(len(counts))
    loop_starts = np.empty(len(counts), dtype=np.int32)
    if len(counts) > 0:
        loop_starts[0] = 0
    if len(counts) > 1:
        np.cumsum(counts[:-1], out=loop_starts[1:])

    mesh.polygons.foreach_set("loop_start", loop_starts)
    mesh.polygons.foreach_set("loop_total", counts)
    mesh.update(calc_edges=True)
    mesh.validate(clean_customdata=False)

    obj = bpy.data.objects.new(object_name, mesh)
    scene.collection.objects.link(obj)
    obj.rotation_euler[0] = math.radians(90.0)

    basis = obj.shape_key_add(name="Basis", from_mix=False)
    basis.value = 1.0
    obj.show_only_shape_key = False
    mesh.update()
    return obj


class FastBakerDirectSettings(bpy.types.PropertyGroup):
    archive_path: StringProperty(
        name="Alembic File",
        subtype="FILE_PATH",
        default="",
    )
    mesh_path: StringProperty(
        name="Mesh Path",
        description="Archive path to the poly mesh. Leave blank and Scan will use the first mesh found",
        default="",
    )
    bake_frame_start: IntProperty(
        name="Start Frame",
        description="Timeline frame where the first Alembic sample will be placed",
        default=1,
    )
    bake_frame_end: IntProperty(
        name="End Frame",
        description="Timeline frame where the last Alembic sample will be placed",
        default=250,
    )
    skip_identical_frames: BoolProperty(
        name="Skip Identical",
        description="Skip shape keys whose coordinates match the basis sample within the tolerance",
        default=False,
    )
    identical_epsilon: FloatProperty(
        name="Tolerance",
        default=0.0,
        min=0.0,
        precision=6,
    )
    use_gpu_compare: BoolProperty(
        name="Use GPU Compare",
        description="Use the optional CUDA max-delta comparison path when available",
        default=True,
    )
    show_timing: BoolProperty(
        name="Show Timing",
        default=True,
    )
    is_baking: BoolProperty(
        name="Is Baking",
        default=False,
        options={"HIDDEN"},
    )
    progress: FloatProperty(
        name="Progress",
        default=0.0,
        min=0.0,
        max=100.0,
        subtype="PERCENTAGE",
        precision=1,
    )
    status_text: StringProperty(
        name="Status",
        default="Idle",
    )
    detected_mesh_count: IntProperty(
        name="Mesh Count",
        default=0,
    )
    detected_sample_count: IntProperty(
        name="Sample Count",
        default=0,
    )
    detected_vertex_count: IntProperty(
        name="Vertex Count",
        default=0,
    )
    detected_face_count: IntProperty(
        name="Face Count",
        default=0,
    )
    backend_core_type: StringProperty(
        name="Core Type",
        default="",
    )
    backend_cuda_device: StringProperty(
        name="CUDA Device",
        default="",
    )
    current_sample: IntProperty(
        name="Current Sample",
        default=0,
    )
    baked_count: IntProperty(
        name="Baked",
        default=0,
    )
    skipped_count: IntProperty(
        name="Skipped",
        default=0,
    )
    result_object_name: StringProperty(
        name="Result Object",
        default="",
    )


class OBJECT_OT_fast_baker_direct_scan(bpy.types.Operator):
    bl_idname = "object.fast_baker_direct_scan"
    bl_label = "Scan Alembic"
    bl_description = "Inspect the Alembic archive and populate mesh/sample info"

    def execute(self, context):
        settings = context.scene.fast_baker_direct_settings

        if baker_backend is None:
            self.report({"ERROR"}, f"Backend import failed: {BACKEND_IMPORT_ERROR}")
            return {"CANCELLED"}

        archive_path = _abs_archive_path(settings)
        if not archive_path or not os.path.isfile(archive_path):
            self.report({"ERROR"}, "Choose a valid Alembic file first.")
            return {"CANCELLED"}

        try:
            meshes = baker_backend.list_poly_meshes(archive_path)
            if not meshes:
                self.report({"ERROR"}, "No poly meshes were found in this archive.")
                return {"CANCELLED"}

            selected_path = settings.mesh_path
            if selected_path:
                matching = [mesh for mesh in meshes if mesh["path"] == selected_path]
                selected_mesh = matching[0] if matching else meshes[0]
            else:
                selected_mesh = meshes[0]

            reader = baker_backend.AlembicMeshReader(archive_path, selected_mesh["path"])
            settings.mesh_path = reader.mesh_path
            if settings.detected_sample_count != reader.sample_count:
                settings.bake_frame_start, settings.bake_frame_end = _suggest_frame_range(
                    context.scene,
                    reader.sample_count,
                )
            settings.detected_mesh_count = len(meshes)
            settings.detected_sample_count = reader.sample_count
            settings.detected_vertex_count = reader.vertex_count
            settings.detected_face_count = reader.face_count
            settings.backend_core_type = reader.core_type
            settings.backend_cuda_device = baker_backend.get_cuda_device_name() if baker_backend.has_cuda_support() else ""
            _set_status(
                settings,
                (
                    f"Scanned {len(meshes)} mesh(es). Using {reader.mesh_path} "
                    f"with {reader.sample_count} sample(s)."
                ),
            )
            self.report({"INFO"}, settings.status_text)
            return {"FINISHED"}
        except Exception as exc:
            _set_status(settings, f"Scan failed: {exc}")
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}


class OBJECT_OT_fast_bake_direct_cancel(bpy.types.Operator):
    bl_idname = "object.fast_bake_direct_cancel"
    bl_label = "Cancel Direct Bake"
    bl_description = "Cancel the active direct Alembic bake and keep any shape keys already baked"

    @classmethod
    def poll(cls, context):
        return context.scene.fast_baker_direct_settings.is_baking

    def execute(self, context):
        if ACTIVE_BAKE_OPERATOR is not None:
            ACTIVE_BAKE_OPERATOR._cancel_requested = True
            context.scene.fast_baker_direct_settings.status_text = "Cancelling after current sample..."
            _tag_redraw_all()
            return {"FINISHED"}

        self.report({"WARNING"}, "No active direct bake to cancel.")
        return {"CANCELLED"}


class OBJECT_OT_fast_bake_direct_shapekeys(bpy.types.Operator):
    bl_idname = "object.fast_bake_direct_shapekeys"
    bl_label = "Bake Direct Alembic"
    bl_description = "Read Alembic samples directly and bake them into shape keys"
    bl_options = {"REGISTER"}

    _timer = None
    _cancel_requested = False

    @classmethod
    def poll(cls, context):
        return not context.scene.fast_baker_direct_settings.is_baking

    def _refresh_result_view(self, context, force=False):
        if self._result_obj is None:
            return

        if not force and self._samples_since_view_refresh < self._viewport_refresh_step:
            return

        t0 = time.perf_counter()
        self._result_obj.data.update()
        context.view_layer.update()
        self._timings["view_refresh"] += time.perf_counter() - t0
        self._samples_since_view_refresh = 0

    def _advance_progress(self, sample_index, skipped):
        self._sample_cursor += 1
        self._settings.current_sample = sample_index
        self._settings.baked_count = self._baked_samples
        self._settings.skipped_count = self._skipped_samples
        self._settings.progress = (self._sample_cursor / max(len(self._bake_sample_numbers), 1)) * 100.0
        bpy.context.window_manager.progress_update(self._sample_cursor)

        if skipped:
            self._settings.status_text = (
                f"Skipped sample {sample_index} | baked {self._baked_samples} | result {self._result_obj.name}"
            )
        else:
            self._settings.status_text = (
                f"Added sample {sample_index} | baked {self._baked_samples} | result {self._result_obj.name}"
            )

    def _timeline_frame_for_sample(self, sample_index):
        if self._sample_count <= 1 or self._timeline_end <= self._timeline_start:
            return self._timeline_start

        sample_progress = sample_index / max(self._sample_count - 1, 1)
        return int(round(self._timeline_start + (sample_progress * (self._timeline_end - self._timeline_start))))

    def _finish(self, context, cancelled=False, error_message=None):
        global ACTIVE_BAKE_OPERATOR

        settings = self._settings

        if self._timer is not None:
            context.window_manager.event_timer_remove(self._timer)
            self._timer = None

        if self._progress_started:
            context.window_manager.progress_end()
            self._progress_started = False
        settings.is_baking = False

        if self._result_obj is not None:
            t0 = time.perf_counter()
            _set_all_shape_key_interpolation_linear(self._result_obj)
            self._refresh_result_view(context, force=True)
            self._timings["finalize"] += time.perf_counter() - t0
            self._result_obj.show_only_shape_key = False
            if self._result_obj.data.shape_keys is not None:
                self._result_obj.active_shape_key_index = max(
                    0,
                    len(self._result_obj.data.shape_keys.key_blocks) - 1,
                )
            self._result_obj.data.update()

            bpy.ops.object.select_all(action="DESELECT")
            self._result_obj.select_set(True)
            context.view_layer.objects.active = self._result_obj

        ACTIVE_BAKE_OPERATOR = None
        _tag_redraw_all()

        total_seconds = sum(self._timings.values())
        summary = (
            f"Created '{self._result_obj.name}' with {self._baked_samples} baked shape key(s), "
            f"skipped {self._skipped_samples}, samples={self._sample_count}, "
            f"threads=auto({self._requested_threads})."
            if self._result_obj is not None
            else "Bake stopped before creating a result object."
        )

        if error_message:
            settings.status_text = f"Error: {error_message}"
            self.report({"ERROR"}, error_message)
            return {"CANCELLED"}

        if cancelled:
            settings.status_text = (
                f"Cancelled at sample {self._last_processed_sample}. "
                f"Partial result kept: {self._result_obj.name}"
            )
            self.report({"WARNING"}, settings.status_text)
            return {"CANCELLED"}

        settings.progress = 100.0
        settings.status_text = f"Done: {self._result_obj.name}"

        if self._settings.show_timing:
            timing_text = ", ".join(f"{name}={value:.3f}s" for name, value in self._timings.items())
            print(f"[Fast Baker Direct] {summary} total={total_seconds:.3f}s :: {timing_text}")
            self.report({"INFO"}, f"{summary} Total {total_seconds:.2f}s")
        else:
            self.report({"INFO"}, summary)

        return {"FINISHED"}

    def _process_one_sample(self, context):
        if self._cancel_requested:
            return self._finish(context, cancelled=True)

        if self._sample_cursor >= len(self._bake_sample_numbers):
            return self._finish(context)

        sample_index = self._bake_sample_numbers[self._sample_cursor]
        self._last_processed_sample = sample_index
        _set_status(self._settings, f"Reading sample {sample_index}...", redraw=False)

        if self._settings.skip_identical_frames:
            t0 = time.perf_counter()
            positions, max_delta = self._reader.read_sample_positions_and_measure_delta(
                sample_index,
                self._basis_array,
                self._output_buffer,
                self._settings.use_gpu_compare,
            )
            self._timings["sample_read"] += time.perf_counter() - t0

            if max_delta <= self._settings.identical_epsilon:
                self._skipped_samples += 1
                self._advance_progress(sample_index, skipped=True)
                return {"RUNNING_MODAL"}
        else:
            t0 = time.perf_counter()
            positions = self._reader.read_sample_positions(sample_index, self._output_buffer)
            self._timings["sample_read"] += time.perf_counter() - t0

        t0 = time.perf_counter()
        timeline_frame = self._timeline_frame_for_sample(sample_index)
        previous_frame = self._timeline_frame_for_sample(max(0, sample_index - 1))
        if sample_index + 1 < self._sample_count:
            next_frame = self._timeline_frame_for_sample(sample_index + 1)
        else:
            next_frame = timeline_frame + max(1, timeline_frame - previous_frame)

        shape_key = self._result_obj.shape_key_add(name=f"Sample_{sample_index:04d}", from_mix=False)
        shape_key_index = len(self._result_obj.data.shape_keys.key_blocks) - 1
        self._result_obj.active_shape_key_index = shape_key_index
        self._result_obj.show_only_shape_key = True
        shape_key.data.foreach_set("co", positions)
        self._result_obj.show_only_shape_key = False

        if self._baked_samples != 0:
            shape_key.value = 0.0
            shape_key.keyframe_insert("value", frame=previous_frame)

        shape_key.value = 1.0
        shape_key.keyframe_insert("value", frame=timeline_frame)
        shape_key.value = 0.0
        shape_key.keyframe_insert("value", frame=next_frame)

        self._samples_since_view_refresh += 1
        self._refresh_result_view(context)

        self._timings["shape_key_write"] += time.perf_counter() - t0
        self._baked_samples += 1
        self._advance_progress(sample_index, skipped=False)
        return {"RUNNING_MODAL"}

    def execute(self, context):
        global ACTIVE_BAKE_OPERATOR

        if baker_backend is None:
            self.report({"ERROR"}, f"Backend import failed: {BACKEND_IMPORT_ERROR}")
            return {"CANCELLED"}

        self._scene = context.scene
        self._settings = context.scene.fast_baker_direct_settings
        self._cancel_requested = False
        self._sample_cursor = 0
        self._baked_samples = 0
        self._skipped_samples = 0
        self._result_obj = None
        self._progress_started = False
        self._samples_since_view_refresh = 0
        self._last_processed_sample = 0
        self._timings = {
            "sample_read": 0.0,
            "shape_key_write": 0.0,
            "view_refresh": 0.0,
            "finalize": 0.0,
        }

        archive_path = _abs_archive_path(self._settings)
        if not archive_path or not os.path.isfile(archive_path):
            self.report({"ERROR"}, "Choose a valid Alembic file first.")
            return {"CANCELLED"}

        try:
            self._reader = baker_backend.AlembicMeshReader(archive_path, self._settings.mesh_path)
        except Exception as exc:
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}

        if not self._reader.stable_topology:
            self.report({"ERROR"}, "This Alembic mesh has heterogenous topology, so shape keys are not safe.")
            return {"CANCELLED"}

        self._sample_count = self._reader.sample_count
        self._timeline_start = int(self._settings.bake_frame_start)
        self._timeline_end = int(self._settings.bake_frame_end)
        if self._sample_count > 1 and self._timeline_end <= self._timeline_start:
            self.report({"ERROR"}, "End frame must be greater than start frame when the Alembic has multiple samples.")
            return {"CANCELLED"}

        self._all_sample_numbers = list(range(self._sample_count))
        self._basis_sample = 0
        self._bake_sample_numbers = self._all_sample_numbers[1:]
        self._requested_threads = max(1, int(baker_backend.get_max_threads() or (os.cpu_count() or 1)))
        self._samples_per_tick = _auto_samples_per_tick(self._reader.vertex_count)
        self._viewport_refresh_step = _auto_viewport_refresh_step(self._reader.vertex_count)
        baker_backend.set_thread_count(self._requested_threads)

        try:
            self._basis_array = self._reader.read_sample_positions(self._basis_sample)
            self._output_buffer = np.empty(self._reader.vertex_count * 3, dtype=np.float32)
            topology_indices = self._reader.read_topology_indices()
            topology_counts = self._reader.read_topology_counts()
        except Exception as exc:
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}

        self._result_obj = _create_mesh_object(
            self._scene,
            archive_path,
            self._reader.mesh_path,
            self._basis_array,
            topology_indices,
            topology_counts,
        )

        bpy.ops.object.select_all(action="DESELECT")
        self._result_obj.select_set(True)
        context.view_layer.objects.active = self._result_obj

        self._settings.mesh_path = self._reader.mesh_path
        self._settings.detected_sample_count = self._reader.sample_count
        self._settings.detected_vertex_count = self._reader.vertex_count
        self._settings.detected_face_count = self._reader.face_count
        self._settings.backend_core_type = self._reader.core_type
        self._settings.backend_cuda_device = baker_backend.get_cuda_device_name() if baker_backend.has_cuda_support() else ""
        self._settings.is_baking = True
        self._settings.progress = 0.0
        self._settings.current_sample = self._basis_sample
        self._settings.baked_count = 0
        self._settings.skipped_count = 0
        self._settings.result_object_name = self._result_obj.name

        if not self._bake_sample_numbers:
            _set_status(
                self._settings,
                f"Created {self._result_obj.name} from basis sample {self._basis_sample}. No extra samples to bake.",
            )
            return self._finish(context)

        _set_status(
            self._settings,
            (
                f"Starting direct bake on {self._result_obj.name} "
                f"across frames {self._timeline_start}-{self._timeline_end}..."
            ),
        )

        context.window_manager.progress_begin(0, len(self._bake_sample_numbers))
        self._progress_started = True
        self._timer = context.window_manager.event_timer_add(0.01, window=context.window)
        context.window_manager.modal_handler_add(self)
        ACTIVE_BAKE_OPERATOR = self
        return {"RUNNING_MODAL"}

    def modal(self, context, event):
        if event.type == "ESC":
            self._cancel_requested = True
            return {"RUNNING_MODAL"}

        if event.type != "TIMER":
            return {"PASS_THROUGH"}

        try:
            for _ in range(max(1, self._samples_per_tick)):
                result = self._process_one_sample(context)
                if result != {"RUNNING_MODAL"}:
                    return result

                if self._sample_cursor >= len(self._bake_sample_numbers) or self._cancel_requested:
                    break

            _tag_redraw_all()
            return {"RUNNING_MODAL"}
        except Exception as exc:
            return self._finish(context, error_message=str(exc))


class VIEW3D_PT_fast_baker_direct(bpy.types.Panel):
    bl_label = "Fast Baker Direct"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Fast Baker"

    def draw(self, context):
        layout = self.layout
        settings = context.scene.fast_baker_direct_settings
        column = layout.column(align=True)

        column.prop(settings, "archive_path")
        if settings.detected_mesh_count > 1 or not settings.mesh_path:
            column.prop(settings, "mesh_path")
        elif settings.mesh_path:
            column.label(text=f"Mesh: {settings.mesh_path}")

        if baker_backend is None:
            column.label(text="Backend unavailable.", icon="ERROR")
            if BACKEND_IMPORT_ERROR:
                column.label(text=BACKEND_IMPORT_ERROR[:60])
            return

        row = column.row(align=True)
        row.operator(OBJECT_OT_fast_baker_direct_scan.bl_idname, icon="FILE_REFRESH")
        if not settings.is_baking:
            row.operator(OBJECT_OT_fast_bake_direct_shapekeys.bl_idname, icon="SHAPEKEY_DATA")

        column.prop(settings, "bake_frame_start")
        column.prop(settings, "bake_frame_end")
        column.prop(settings, "skip_identical_frames")
        if settings.skip_identical_frames:
            column.prop(settings, "identical_epsilon")
            column.prop(settings, "use_gpu_compare")
        column.prop(settings, "show_timing")

        info_box = layout.box()
        info_box.label(text=f"Status: {settings.status_text}")
        progress_col = info_box.column(align=True)
        progress_col.enabled = False
        progress_col.prop(settings, "progress", slider=True, text="Progress")
        info_box.label(text=f"Frame Range: {settings.bake_frame_start} - {settings.bake_frame_end}")
        info_box.label(text=f"Meshes: {settings.detected_mesh_count}")
        info_box.label(text=f"Samples: {settings.detected_sample_count}")
        info_box.label(text=f"Vertices: {settings.detected_vertex_count} | Faces: {settings.detected_face_count}")
        if settings.backend_core_type:
            info_box.label(text=f"Alembic Core: {settings.backend_core_type}")
        if settings.backend_cuda_device:
            info_box.label(text=f"CUDA: {settings.backend_cuda_device}")
        else:
            info_box.label(text=f"CUDA Compare: {'Available' if baker_backend.has_cuda_support() else 'Unavailable'}")
        if settings.mesh_path:
            info_box.label(text=f"Mesh: {settings.mesh_path}")
        if settings.result_object_name:
            info_box.label(text=f"Result: {settings.result_object_name}")
        info_box.label(text=f"Current Sample: {settings.current_sample}")
        info_box.label(text=f"Baked: {settings.baked_count} | Skipped: {settings.skipped_count}")

        if settings.is_baking:
            layout.operator(OBJECT_OT_fast_bake_direct_cancel.bl_idname, icon="CANCEL")


CLASSES = (
    FastBakerDirectSettings,
    OBJECT_OT_fast_baker_direct_scan,
    OBJECT_OT_fast_bake_direct_cancel,
    OBJECT_OT_fast_bake_direct_shapekeys,
    VIEW3D_PT_fast_baker_direct,
)


def register():
    for cls in CLASSES:
        bpy.utils.register_class(cls)
    bpy.types.Scene.fast_baker_direct_settings = PointerProperty(type=FastBakerDirectSettings)


def unregister():
    global ACTIVE_BAKE_OPERATOR

    ACTIVE_BAKE_OPERATOR = None
    del bpy.types.Scene.fast_baker_direct_settings
    for cls in reversed(CLASSES):
        bpy.utils.unregister_class(cls)
