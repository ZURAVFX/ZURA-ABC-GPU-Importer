# Fast Baker Direct ABC GPU

This is a separate side-by-side prototype that bypasses Blender's Alembic modifier/depsgraph sampling path.

## What is different from `fast_baker`

- Reads `.abc` files directly through the official Alembic C++ library.
- Builds the result mesh once from archive topology, then bakes shape keys from direct sample reads.
- Applies Alembic parent xforms during sample reads so imported orientation matches the source hierarchy more closely.
- Keeps the current addon untouched so both versions can be compared on the same machine.
- Includes an optional CUDA max-delta comparison path for `Skip Identical`.

## Current scope

- Targets poly mesh Alembic caches.
- Defaults to the first poly mesh in the archive unless you provide a mesh path.
- Uses a simple start-frame/end-frame workflow and auto-tunes internal batching/thread usage.
- Requires non-heterogenous topology for shape key baking.
- Main speed gain comes from bypassing Blender's per-frame Alembic evaluation. The CUDA path is secondary and mostly useful on very large caches.

## Build

- Windows: run `build.bat`
- Linux/macOS: run `build.sh`

The build uses:

- `_upstream/Imath`
- `_upstream/alembic`
- `pybind11` via CMake `FetchContent`

## Files

- `__init__.py`: Blender addon
- `src/direct_abc_backend.cpp`: direct Alembic reader backend
- `src/cuda_compare.cu`: optional CUDA compare helper
- `CMakeLists.txt`: build configuration
